package com.example.fieldagents;
import ourClasses.*;

public class AddReading {

    public AddReading(String siteId, String readingType, String readingId, Double readingVal, String readingDate){
        // Add a reading into the activeSites list
        // not entirely sure about the index value get(0). This value might need to be continuously incremented
        //
        AllSites.activeSites.get(0).addAReading(siteId, readingType, readingId, readingVal, readingDate);
    }

}
