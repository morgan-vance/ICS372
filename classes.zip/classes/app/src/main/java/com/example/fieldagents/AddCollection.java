package com.example.fieldagents;

import ourClasses.*;

public class AddCollection {

    public AddCollection(String siteId){

        //Add a site into the activeSites collection
        AllSites.activeSites.add(new Site(siteId));
    }

    // Find the site from the activeSites list
    public boolean findSite(String siteId){
        for(Site site: AllSites.activeSites){
            if(siteId.equals(site.readings.element().getSiteId())) {
                System.out.println("The site is found");
                return true;
            }
        }
        return false;
    }


}
