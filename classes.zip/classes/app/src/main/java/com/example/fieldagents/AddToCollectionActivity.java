package com.example.fieldagents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddToCollectionActivity extends AppCompatActivity implements View.OnClickListener {
    EditText siteID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_collection);

        siteID = (EditText) findViewById(R.id.editSiteID);

        Button submit = (Button) findViewById(R.id.buttonAddCollection);
        submit.setOnClickListener(this);
    }

    public void loadData(){
        String siteId;

        siteId = siteID.getText().toString().trim();

        // If the input label is empty
        if(siteId.isEmpty()){
            siteID.setError("Site ID Is Required");
            siteID.requestFocus();

        }

        AddCollection newSite = new AddCollection(siteId);

        /* check to see if the site is indeed in the activeSite's collection
          boolean val =  newSite.findSite(siteId);
          if(val == true){
              Toast.makeText(getApplicationContext(), "Site Has Been Found.", Toast.LENGTH_SHORT).show();

          } */
    }


    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.buttonAddCollection:
                loadData();
                Toast.makeText(getApplicationContext(), "Site Has Been Added To The Collection.", Toast.LENGTH_SHORT).show();

                break;
        }
    }
}
