package com.example.fieldagents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

public class AddAReadingActivity extends AppCompatActivity implements View.OnClickListener {

    EditText siteID, readingType, readingID, readingValue, readingDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_areading2);

        siteID = (EditText) findViewById(R.id.editSiteID);
        readingType = (EditText) findViewById(R.id.editReadingType);
        readingID = (EditText) findViewById(R.id.editReadingID);
        readingValue = (EditText) findViewById(R.id.editReadingValue);
        readingDate = (EditText) findViewById(R.id.editReadingDate);

        Button submit = (Button) findViewById(R.id.buttonReading);


        submit.setOnClickListener(this);


    }

    public void loadData(){

        String siteId, type, readingId, readingVal, date;

        siteId = siteID.getText().toString().trim();
        type = readingType.getText().toString().trim();
        readingId = readingID.getText().toString().trim();
        readingVal = readingValue.getText().toString().trim();
        date = readingDate.getText().toString().trim();

        double newNum =  Double.parseDouble(readingVal);
        if(siteId.isEmpty()){
            siteID.setError("Site ID Is Required");
            siteID.requestFocus();

        }
        if(type.isEmpty()){
            readingType.setError("Reading Type Is Required");
            readingType.requestFocus();

        }
        if(readingId.isEmpty()){
            readingID.setError("Reading ID Is Required");
            readingID.requestFocus();

        }
        if(readingVal.isEmpty()){
            readingValue.setError("Reading Value Is Required");
            readingValue.requestFocus();

        }
        if(date.isEmpty()){
            readingDate.setError("Reading Date Is Required");
            readingDate.requestFocus();

        }


        // This should add the entered values into the activeSite list but, It is giving a null pointer exception
        AddReading data = new AddReading(siteId,type,readingId,newNum,date);



    }

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.buttonReading:
               loadData();
                Toast.makeText(getApplicationContext(), "Data has been added.", Toast.LENGTH_SHORT).show();

                break;

        }
    }
}
