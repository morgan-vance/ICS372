package com.example.fieldagents;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class JSONActivity extends AppCompatActivity implements View.OnClickListener{

    private JSON jsonInfo = new JSON();

    //to display to screen
    TextView screen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json);

        //find the button
        Button buttonReadJson = findViewById(R.id.buttonReadJson);
        //listen for clicks
        buttonReadJson.setOnClickListener(this);

        Button buttonImportJson = findViewById(R.id.buttonImportJSON);
        buttonImportJson.setOnClickListener(this);

        screen = findViewById(R.id.textShow); //display json thats read
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonReadJson:


                //String readingsList= jsonInfo.readJSON();
                //screen.setText(readingsList);
                //mini notiication on screen
                Toast.makeText(getApplicationContext(), "Button Read JSON clicked!",
                        Toast.LENGTH_LONG).show();
                break;

            case R.id.buttonImportJSON:

                //get the file from android
                File fileDir = Environment.getExternalStorageDirectory();

                //json file is in sdcard
                File file = new File(fileDir + "/Download/json/example.json");
                // File file = new File(fileDir, "/sdcard/Downloads/json/example.json")

                String readings = jsonInfo.readJSON(file);
                screen.setText(readings); // display the output to the Android screen



                //mini notiication on screen
                Toast.makeText(getApplicationContext(), "JSON Is imported!",
                        Toast.LENGTH_LONG).show();
                break;

        }
    }
}
