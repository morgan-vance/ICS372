package com.example.fieldagents;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

public class AddReadingFragment extends Fragment implements View.OnClickListener  {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_addreading, container, false);


        Button btnOpen = (Button) view.findViewById(R.id.btnOpen);

       // submit.setOnClickListener(this);

        btnOpen.setOnClickListener(this);

        return view;
    }


  @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btnOpen:
                Intent intent = new Intent(getActivity(), AddAReadingActivity.class);
                startActivity(intent);
                break;
        }
  }
}
