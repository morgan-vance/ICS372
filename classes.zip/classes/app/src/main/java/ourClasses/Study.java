/**
 *
 */
package ourClasses;

/**
 *Study class keeps track of readings for studies.
 *There are three status for a study:
 *
 *Active Sites :           Study of sites that can add or show readings
 *Site Collection Disable: Study of sites that cant add, but can show readings
 *Site Invalid :           Study of sites that cannot add or show readings
 *Completed Study:         Study of sites that can only show readings
 */
public class Study {

    //list of studies with active sites
    //list of site invalid studies
    // list of completed studies
    //list of site collection disable studiy

    //private studyStatus = "Site Invalid";
    Site s;


    //method to take in a site object and add it to a list
    //Method to display all the readings, given the status of a study
}
