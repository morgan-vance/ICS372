package com.example.fieldcollection;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import ourClasses.Site;




public class ExportActivity extends AppCompatActivity implements View.OnClickListener{


    private JSON jsonInfo = new JSON();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_export);


        Button buttonImportJson = findViewById(R.id.buttonExportJSON);
        buttonImportJson.setOnClickListener(this);

        Button buttonImportXML = findViewById(R.id.buttonExportXML);
        buttonImportXML.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.buttonExportJSON:

                //call exporting function for  a JSON file
                ReaderWriter.fileWriter(Site.formatSiteForExport());


                //mini notiication on screen
                Toast.makeText(getApplicationContext(), "JSON Is Exported!",
                        Toast.LENGTH_LONG).show();


                //Launch back to Main Activity
                Intent intent = new Intent(ExportActivity.this, MainActivity.class);
                startActivity(intent);
                break;

            case R.id.buttonExportXML:



                //mini notiication on screen
                Toast.makeText(getApplicationContext(), "XML Is Exported!",
                        Toast.LENGTH_LONG).show();


            //Launch back to Main Activity
                Intent i = new Intent(ExportActivity.this, MainActivity.class);
                startActivity(i);
                break;


        }


    }
}

